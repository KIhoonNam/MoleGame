﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class GameButton : MonoBehaviour
{
    




    public void StartButton()
    {
        SceneManager.LoadScene("MainScene");
        GameManger.instance.GetPlayerStat().Damage = 2;
        SLManager.Save();
    }

    public void RestartButton()
    {
        SceneManager.LoadScene("MainScene");
    }

    public void HomeButton()
    {
        SceneManager.LoadScene("IntroScene");
    }
}

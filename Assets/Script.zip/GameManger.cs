﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerState
{
    public int Damage;
    public int Coin;
    public int MaxScore;
    public int GamePlayTime;

    public  PlayerState(int _damage, int _coin, int _maxscore, int _gameplaytime)
    {
        Damage = _damage;
        Coin = _coin;
        MaxScore = _maxscore;
        GamePlayTime = _gameplaytime;
    }
};

public enum GameState
{
    INTRO,
    SHOP,
    STAGE
}


public class GameManger : MonoBehaviour
{
    public static GameManger instance;

    public GameState gamestate;
    public PlayerState PlayerStat;
    
    private void Awake()
    {
        if(instance == null)
        {
            instance = this;

        

        }
        DontDestroyOnLoad(this);
        gamestate = GameState.INTRO;
        SLManager.Load();
    }

    private void Start()
    {
        
    }

    public PlayerState GetPlayerStat()
    {
        return PlayerStat;
    }
    
    public void SetPlayerStat(PlayerState _playerstat)
    {
        PlayerStat = _playerstat;
    }

    

    // Update is called once per frame
    void Update()
    {

        if(Input.GetKeyDown(KeyCode.Escape))
        {
            if(gamestate == GameState.INTRO)
            {
                Application.Quit();
            }
        }
    }
}
